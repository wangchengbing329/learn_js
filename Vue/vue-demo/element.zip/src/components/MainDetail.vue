<template>
    <div class="main-detail">{{msg}}</div>
</template>
<script>
export default {
    name:"MainDetail",
    data (){
        return {
            msg:"这是默认首页"
        }
    }
}
</script>
